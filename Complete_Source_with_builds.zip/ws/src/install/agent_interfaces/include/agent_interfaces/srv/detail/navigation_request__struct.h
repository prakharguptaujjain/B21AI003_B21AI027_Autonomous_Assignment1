// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from agent_interfaces:srv/NavigationRequest.idl
// generated code does not contain a copyright notice

#ifndef AGENT_INTERFACES__SRV__DETAIL__NAVIGATION_REQUEST__STRUCT_H_
#define AGENT_INTERFACES__SRV__DETAIL__NAVIGATION_REQUEST__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'visitor_id'
// Member 'host_location'
#include "rosidl_runtime_c/string.h"

// Struct defined in srv/NavigationRequest in the package agent_interfaces.
typedef struct agent_interfaces__srv__NavigationRequest_Request
{
  rosidl_runtime_c__String visitor_id;
  rosidl_runtime_c__String host_location;
  bool ossrequest;
  int32_t ossmeettime;
} agent_interfaces__srv__NavigationRequest_Request;

// Struct for a sequence of agent_interfaces__srv__NavigationRequest_Request.
typedef struct agent_interfaces__srv__NavigationRequest_Request__Sequence
{
  agent_interfaces__srv__NavigationRequest_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} agent_interfaces__srv__NavigationRequest_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'path'
// Member 'denial_reason'
// already included above
// #include "rosidl_runtime_c/string.h"

// Struct defined in srv/NavigationRequest in the package agent_interfaces.
typedef struct agent_interfaces__srv__NavigationRequest_Response
{
  bool authorized;
  rosidl_runtime_c__String path;
  rosidl_runtime_c__String denial_reason;
  int32_t osswaittime;
} agent_interfaces__srv__NavigationRequest_Response;

// Struct for a sequence of agent_interfaces__srv__NavigationRequest_Response.
typedef struct agent_interfaces__srv__NavigationRequest_Response__Sequence
{
  agent_interfaces__srv__NavigationRequest_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} agent_interfaces__srv__NavigationRequest_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AGENT_INTERFACES__SRV__DETAIL__NAVIGATION_REQUEST__STRUCT_H_
