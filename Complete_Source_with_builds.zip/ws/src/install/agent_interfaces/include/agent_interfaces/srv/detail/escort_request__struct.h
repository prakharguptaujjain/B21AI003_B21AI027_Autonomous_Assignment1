// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from agent_interfaces:srv/EscortRequest.idl
// generated code does not contain a copyright notice

#ifndef AGENT_INTERFACES__SRV__DETAIL__ESCORT_REQUEST__STRUCT_H_
#define AGENT_INTERFACES__SRV__DETAIL__ESCORT_REQUEST__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'visitor_id'
// Member 'building_location'
// Member 'room_number'
#include "rosidl_runtime_c/string.h"

// Struct defined in srv/EscortRequest in the package agent_interfaces.
typedef struct agent_interfaces__srv__EscortRequest_Request
{
  rosidl_runtime_c__String visitor_id;
  rosidl_runtime_c__String building_location;
  rosidl_runtime_c__String room_number;
  bool ossrequest;
  int32_t ossmeettime;
} agent_interfaces__srv__EscortRequest_Request;

// Struct for a sequence of agent_interfaces__srv__EscortRequest_Request.
typedef struct agent_interfaces__srv__EscortRequest_Request__Sequence
{
  agent_interfaces__srv__EscortRequest_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} agent_interfaces__srv__EscortRequest_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
// Member 'path'
// already included above
// #include "rosidl_runtime_c/string.h"

// Struct defined in srv/EscortRequest in the package agent_interfaces.
typedef struct agent_interfaces__srv__EscortRequest_Response
{
  bool success;
  rosidl_runtime_c__String message;
  rosidl_runtime_c__String path;
} agent_interfaces__srv__EscortRequest_Response;

// Struct for a sequence of agent_interfaces__srv__EscortRequest_Response.
typedef struct agent_interfaces__srv__EscortRequest_Response__Sequence
{
  agent_interfaces__srv__EscortRequest_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} agent_interfaces__srv__EscortRequest_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AGENT_INTERFACES__SRV__DETAIL__ESCORT_REQUEST__STRUCT_H_
