// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from agent_interfaces:srv/NavigationRequest.idl
// generated code does not contain a copyright notice

#ifndef AGENT_INTERFACES__SRV__DETAIL__NAVIGATION_REQUEST__TRAITS_HPP_
#define AGENT_INTERFACES__SRV__DETAIL__NAVIGATION_REQUEST__TRAITS_HPP_

#include "agent_interfaces/srv/detail/navigation_request__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<agent_interfaces::srv::NavigationRequest_Request>()
{
  return "agent_interfaces::srv::NavigationRequest_Request";
}

template<>
inline const char * name<agent_interfaces::srv::NavigationRequest_Request>()
{
  return "agent_interfaces/srv/NavigationRequest_Request";
}

template<>
struct has_fixed_size<agent_interfaces::srv::NavigationRequest_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<agent_interfaces::srv::NavigationRequest_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<agent_interfaces::srv::NavigationRequest_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<agent_interfaces::srv::NavigationRequest_Response>()
{
  return "agent_interfaces::srv::NavigationRequest_Response";
}

template<>
inline const char * name<agent_interfaces::srv::NavigationRequest_Response>()
{
  return "agent_interfaces/srv/NavigationRequest_Response";
}

template<>
struct has_fixed_size<agent_interfaces::srv::NavigationRequest_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<agent_interfaces::srv::NavigationRequest_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<agent_interfaces::srv::NavigationRequest_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<agent_interfaces::srv::NavigationRequest>()
{
  return "agent_interfaces::srv::NavigationRequest";
}

template<>
inline const char * name<agent_interfaces::srv::NavigationRequest>()
{
  return "agent_interfaces/srv/NavigationRequest";
}

template<>
struct has_fixed_size<agent_interfaces::srv::NavigationRequest>
  : std::integral_constant<
    bool,
    has_fixed_size<agent_interfaces::srv::NavigationRequest_Request>::value &&
    has_fixed_size<agent_interfaces::srv::NavigationRequest_Response>::value
  >
{
};

template<>
struct has_bounded_size<agent_interfaces::srv::NavigationRequest>
  : std::integral_constant<
    bool,
    has_bounded_size<agent_interfaces::srv::NavigationRequest_Request>::value &&
    has_bounded_size<agent_interfaces::srv::NavigationRequest_Response>::value
  >
{
};

template<>
struct is_service<agent_interfaces::srv::NavigationRequest>
  : std::true_type
{
};

template<>
struct is_service_request<agent_interfaces::srv::NavigationRequest_Request>
  : std::true_type
{
};

template<>
struct is_service_response<agent_interfaces::srv::NavigationRequest_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // AGENT_INTERFACES__SRV__DETAIL__NAVIGATION_REQUEST__TRAITS_HPP_
