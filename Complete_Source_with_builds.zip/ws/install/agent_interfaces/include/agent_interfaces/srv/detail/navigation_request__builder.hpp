// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from agent_interfaces:srv/NavigationRequest.idl
// generated code does not contain a copyright notice

#ifndef AGENT_INTERFACES__SRV__DETAIL__NAVIGATION_REQUEST__BUILDER_HPP_
#define AGENT_INTERFACES__SRV__DETAIL__NAVIGATION_REQUEST__BUILDER_HPP_

#include "agent_interfaces/srv/detail/navigation_request__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace agent_interfaces
{

namespace srv
{

namespace builder
{

class Init_NavigationRequest_Request_oosmeettime
{
public:
  explicit Init_NavigationRequest_Request_oosmeettime(::agent_interfaces::srv::NavigationRequest_Request & msg)
  : msg_(msg)
  {}
  ::agent_interfaces::srv::NavigationRequest_Request oosmeettime(::agent_interfaces::srv::NavigationRequest_Request::_oosmeettime_type arg)
  {
    msg_.oosmeettime = std::move(arg);
    return std::move(msg_);
  }

private:
  ::agent_interfaces::srv::NavigationRequest_Request msg_;
};

class Init_NavigationRequest_Request_oosrequest
{
public:
  explicit Init_NavigationRequest_Request_oosrequest(::agent_interfaces::srv::NavigationRequest_Request & msg)
  : msg_(msg)
  {}
  Init_NavigationRequest_Request_oosmeettime oosrequest(::agent_interfaces::srv::NavigationRequest_Request::_oosrequest_type arg)
  {
    msg_.oosrequest = std::move(arg);
    return Init_NavigationRequest_Request_oosmeettime(msg_);
  }

private:
  ::agent_interfaces::srv::NavigationRequest_Request msg_;
};

class Init_NavigationRequest_Request_host_location
{
public:
  explicit Init_NavigationRequest_Request_host_location(::agent_interfaces::srv::NavigationRequest_Request & msg)
  : msg_(msg)
  {}
  Init_NavigationRequest_Request_oosrequest host_location(::agent_interfaces::srv::NavigationRequest_Request::_host_location_type arg)
  {
    msg_.host_location = std::move(arg);
    return Init_NavigationRequest_Request_oosrequest(msg_);
  }

private:
  ::agent_interfaces::srv::NavigationRequest_Request msg_;
};

class Init_NavigationRequest_Request_visitor_id
{
public:
  Init_NavigationRequest_Request_visitor_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_NavigationRequest_Request_host_location visitor_id(::agent_interfaces::srv::NavigationRequest_Request::_visitor_id_type arg)
  {
    msg_.visitor_id = std::move(arg);
    return Init_NavigationRequest_Request_host_location(msg_);
  }

private:
  ::agent_interfaces::srv::NavigationRequest_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::agent_interfaces::srv::NavigationRequest_Request>()
{
  return agent_interfaces::srv::builder::Init_NavigationRequest_Request_visitor_id();
}

}  // namespace agent_interfaces


namespace agent_interfaces
{

namespace srv
{

namespace builder
{

class Init_NavigationRequest_Response_ooswaittime
{
public:
  explicit Init_NavigationRequest_Response_ooswaittime(::agent_interfaces::srv::NavigationRequest_Response & msg)
  : msg_(msg)
  {}
  ::agent_interfaces::srv::NavigationRequest_Response ooswaittime(::agent_interfaces::srv::NavigationRequest_Response::_ooswaittime_type arg)
  {
    msg_.ooswaittime = std::move(arg);
    return std::move(msg_);
  }

private:
  ::agent_interfaces::srv::NavigationRequest_Response msg_;
};

class Init_NavigationRequest_Response_denial_reason
{
public:
  explicit Init_NavigationRequest_Response_denial_reason(::agent_interfaces::srv::NavigationRequest_Response & msg)
  : msg_(msg)
  {}
  Init_NavigationRequest_Response_ooswaittime denial_reason(::agent_interfaces::srv::NavigationRequest_Response::_denial_reason_type arg)
  {
    msg_.denial_reason = std::move(arg);
    return Init_NavigationRequest_Response_ooswaittime(msg_);
  }

private:
  ::agent_interfaces::srv::NavigationRequest_Response msg_;
};

class Init_NavigationRequest_Response_path
{
public:
  explicit Init_NavigationRequest_Response_path(::agent_interfaces::srv::NavigationRequest_Response & msg)
  : msg_(msg)
  {}
  Init_NavigationRequest_Response_denial_reason path(::agent_interfaces::srv::NavigationRequest_Response::_path_type arg)
  {
    msg_.path = std::move(arg);
    return Init_NavigationRequest_Response_denial_reason(msg_);
  }

private:
  ::agent_interfaces::srv::NavigationRequest_Response msg_;
};

class Init_NavigationRequest_Response_authorized
{
public:
  Init_NavigationRequest_Response_authorized()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_NavigationRequest_Response_path authorized(::agent_interfaces::srv::NavigationRequest_Response::_authorized_type arg)
  {
    msg_.authorized = std::move(arg);
    return Init_NavigationRequest_Response_path(msg_);
  }

private:
  ::agent_interfaces::srv::NavigationRequest_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::agent_interfaces::srv::NavigationRequest_Response>()
{
  return agent_interfaces::srv::builder::Init_NavigationRequest_Response_authorized();
}

}  // namespace agent_interfaces

#endif  // AGENT_INTERFACES__SRV__DETAIL__NAVIGATION_REQUEST__BUILDER_HPP_
