// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from agent_interfaces:srv/EscortRequest.idl
// generated code does not contain a copyright notice

#ifndef AGENT_INTERFACES__SRV__DETAIL__ESCORT_REQUEST__STRUCT_HPP_
#define AGENT_INTERFACES__SRV__DETAIL__ESCORT_REQUEST__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__agent_interfaces__srv__EscortRequest_Request __attribute__((deprecated))
#else
# define DEPRECATED__agent_interfaces__srv__EscortRequest_Request __declspec(deprecated)
#endif

namespace agent_interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct EscortRequest_Request_
{
  using Type = EscortRequest_Request_<ContainerAllocator>;

  explicit EscortRequest_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->visitor_id = "";
      this->building_location = "";
      this->room_number = "";
      this->oosrequest = false;
      this->oosmeettime = 0l;
    }
  }

  explicit EscortRequest_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : visitor_id(_alloc),
    building_location(_alloc),
    room_number(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->visitor_id = "";
      this->building_location = "";
      this->room_number = "";
      this->oosrequest = false;
      this->oosmeettime = 0l;
    }
  }

  // field types and members
  using _visitor_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _visitor_id_type visitor_id;
  using _building_location_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _building_location_type building_location;
  using _room_number_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _room_number_type room_number;
  using _oosrequest_type =
    bool;
  _oosrequest_type oosrequest;
  using _oosmeettime_type =
    int32_t;
  _oosmeettime_type oosmeettime;

  // setters for named parameter idiom
  Type & set__visitor_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->visitor_id = _arg;
    return *this;
  }
  Type & set__building_location(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->building_location = _arg;
    return *this;
  }
  Type & set__room_number(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->room_number = _arg;
    return *this;
  }
  Type & set__oosrequest(
    const bool & _arg)
  {
    this->oosrequest = _arg;
    return *this;
  }
  Type & set__oosmeettime(
    const int32_t & _arg)
  {
    this->oosmeettime = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    agent_interfaces::srv::EscortRequest_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const agent_interfaces::srv::EscortRequest_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<agent_interfaces::srv::EscortRequest_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<agent_interfaces::srv::EscortRequest_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      agent_interfaces::srv::EscortRequest_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<agent_interfaces::srv::EscortRequest_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      agent_interfaces::srv::EscortRequest_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<agent_interfaces::srv::EscortRequest_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<agent_interfaces::srv::EscortRequest_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<agent_interfaces::srv::EscortRequest_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__agent_interfaces__srv__EscortRequest_Request
    std::shared_ptr<agent_interfaces::srv::EscortRequest_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__agent_interfaces__srv__EscortRequest_Request
    std::shared_ptr<agent_interfaces::srv::EscortRequest_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const EscortRequest_Request_ & other) const
  {
    if (this->visitor_id != other.visitor_id) {
      return false;
    }
    if (this->building_location != other.building_location) {
      return false;
    }
    if (this->room_number != other.room_number) {
      return false;
    }
    if (this->oosrequest != other.oosrequest) {
      return false;
    }
    if (this->oosmeettime != other.oosmeettime) {
      return false;
    }
    return true;
  }
  bool operator!=(const EscortRequest_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct EscortRequest_Request_

// alias to use template instance with default allocator
using EscortRequest_Request =
  agent_interfaces::srv::EscortRequest_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace agent_interfaces


#ifndef _WIN32
# define DEPRECATED__agent_interfaces__srv__EscortRequest_Response __attribute__((deprecated))
#else
# define DEPRECATED__agent_interfaces__srv__EscortRequest_Response __declspec(deprecated)
#endif

namespace agent_interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct EscortRequest_Response_
{
  using Type = EscortRequest_Response_<ContainerAllocator>;

  explicit EscortRequest_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->message = "";
      this->path = "";
      this->ooswaittime = 0l;
    }
  }

  explicit EscortRequest_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : message(_alloc),
    path(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->message = "";
      this->path = "";
      this->ooswaittime = 0l;
    }
  }

  // field types and members
  using _success_type =
    bool;
  _success_type success;
  using _message_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _message_type message;
  using _path_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _path_type path;
  using _ooswaittime_type =
    int32_t;
  _ooswaittime_type ooswaittime;

  // setters for named parameter idiom
  Type & set__success(
    const bool & _arg)
  {
    this->success = _arg;
    return *this;
  }
  Type & set__message(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->message = _arg;
    return *this;
  }
  Type & set__path(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->path = _arg;
    return *this;
  }
  Type & set__ooswaittime(
    const int32_t & _arg)
  {
    this->ooswaittime = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    agent_interfaces::srv::EscortRequest_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const agent_interfaces::srv::EscortRequest_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<agent_interfaces::srv::EscortRequest_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<agent_interfaces::srv::EscortRequest_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      agent_interfaces::srv::EscortRequest_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<agent_interfaces::srv::EscortRequest_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      agent_interfaces::srv::EscortRequest_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<agent_interfaces::srv::EscortRequest_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<agent_interfaces::srv::EscortRequest_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<agent_interfaces::srv::EscortRequest_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__agent_interfaces__srv__EscortRequest_Response
    std::shared_ptr<agent_interfaces::srv::EscortRequest_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__agent_interfaces__srv__EscortRequest_Response
    std::shared_ptr<agent_interfaces::srv::EscortRequest_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const EscortRequest_Response_ & other) const
  {
    if (this->success != other.success) {
      return false;
    }
    if (this->message != other.message) {
      return false;
    }
    if (this->path != other.path) {
      return false;
    }
    if (this->ooswaittime != other.ooswaittime) {
      return false;
    }
    return true;
  }
  bool operator!=(const EscortRequest_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct EscortRequest_Response_

// alias to use template instance with default allocator
using EscortRequest_Response =
  agent_interfaces::srv::EscortRequest_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace agent_interfaces

namespace agent_interfaces
{

namespace srv
{

struct EscortRequest
{
  using Request = agent_interfaces::srv::EscortRequest_Request;
  using Response = agent_interfaces::srv::EscortRequest_Response;
};

}  // namespace srv

}  // namespace agent_interfaces

#endif  // AGENT_INTERFACES__SRV__DETAIL__ESCORT_REQUEST__STRUCT_HPP_
