// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from agent_interfaces:srv/NavigationRequest.idl
// generated code does not contain a copyright notice

#ifndef AGENT_INTERFACES__SRV__DETAIL__NAVIGATION_REQUEST__STRUCT_HPP_
#define AGENT_INTERFACES__SRV__DETAIL__NAVIGATION_REQUEST__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__agent_interfaces__srv__NavigationRequest_Request __attribute__((deprecated))
#else
# define DEPRECATED__agent_interfaces__srv__NavigationRequest_Request __declspec(deprecated)
#endif

namespace agent_interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct NavigationRequest_Request_
{
  using Type = NavigationRequest_Request_<ContainerAllocator>;

  explicit NavigationRequest_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->visitor_id = "";
      this->host_location = "";
      this->oosrequest = false;
      this->oosmeettime = 0l;
    }
  }

  explicit NavigationRequest_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : visitor_id(_alloc),
    host_location(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->visitor_id = "";
      this->host_location = "";
      this->oosrequest = false;
      this->oosmeettime = 0l;
    }
  }

  // field types and members
  using _visitor_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _visitor_id_type visitor_id;
  using _host_location_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _host_location_type host_location;
  using _oosrequest_type =
    bool;
  _oosrequest_type oosrequest;
  using _oosmeettime_type =
    int32_t;
  _oosmeettime_type oosmeettime;

  // setters for named parameter idiom
  Type & set__visitor_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->visitor_id = _arg;
    return *this;
  }
  Type & set__host_location(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->host_location = _arg;
    return *this;
  }
  Type & set__oosrequest(
    const bool & _arg)
  {
    this->oosrequest = _arg;
    return *this;
  }
  Type & set__oosmeettime(
    const int32_t & _arg)
  {
    this->oosmeettime = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    agent_interfaces::srv::NavigationRequest_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const agent_interfaces::srv::NavigationRequest_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<agent_interfaces::srv::NavigationRequest_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<agent_interfaces::srv::NavigationRequest_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      agent_interfaces::srv::NavigationRequest_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<agent_interfaces::srv::NavigationRequest_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      agent_interfaces::srv::NavigationRequest_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<agent_interfaces::srv::NavigationRequest_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<agent_interfaces::srv::NavigationRequest_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<agent_interfaces::srv::NavigationRequest_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__agent_interfaces__srv__NavigationRequest_Request
    std::shared_ptr<agent_interfaces::srv::NavigationRequest_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__agent_interfaces__srv__NavigationRequest_Request
    std::shared_ptr<agent_interfaces::srv::NavigationRequest_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const NavigationRequest_Request_ & other) const
  {
    if (this->visitor_id != other.visitor_id) {
      return false;
    }
    if (this->host_location != other.host_location) {
      return false;
    }
    if (this->oosrequest != other.oosrequest) {
      return false;
    }
    if (this->oosmeettime != other.oosmeettime) {
      return false;
    }
    return true;
  }
  bool operator!=(const NavigationRequest_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct NavigationRequest_Request_

// alias to use template instance with default allocator
using NavigationRequest_Request =
  agent_interfaces::srv::NavigationRequest_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace agent_interfaces


#ifndef _WIN32
# define DEPRECATED__agent_interfaces__srv__NavigationRequest_Response __attribute__((deprecated))
#else
# define DEPRECATED__agent_interfaces__srv__NavigationRequest_Response __declspec(deprecated)
#endif

namespace agent_interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct NavigationRequest_Response_
{
  using Type = NavigationRequest_Response_<ContainerAllocator>;

  explicit NavigationRequest_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->authorized = false;
      this->path = "";
      this->denial_reason = "";
      this->ooswaittime = 0l;
    }
  }

  explicit NavigationRequest_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : path(_alloc),
    denial_reason(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->authorized = false;
      this->path = "";
      this->denial_reason = "";
      this->ooswaittime = 0l;
    }
  }

  // field types and members
  using _authorized_type =
    bool;
  _authorized_type authorized;
  using _path_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _path_type path;
  using _denial_reason_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _denial_reason_type denial_reason;
  using _ooswaittime_type =
    int32_t;
  _ooswaittime_type ooswaittime;

  // setters for named parameter idiom
  Type & set__authorized(
    const bool & _arg)
  {
    this->authorized = _arg;
    return *this;
  }
  Type & set__path(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->path = _arg;
    return *this;
  }
  Type & set__denial_reason(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->denial_reason = _arg;
    return *this;
  }
  Type & set__ooswaittime(
    const int32_t & _arg)
  {
    this->ooswaittime = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    agent_interfaces::srv::NavigationRequest_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const agent_interfaces::srv::NavigationRequest_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<agent_interfaces::srv::NavigationRequest_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<agent_interfaces::srv::NavigationRequest_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      agent_interfaces::srv::NavigationRequest_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<agent_interfaces::srv::NavigationRequest_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      agent_interfaces::srv::NavigationRequest_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<agent_interfaces::srv::NavigationRequest_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<agent_interfaces::srv::NavigationRequest_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<agent_interfaces::srv::NavigationRequest_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__agent_interfaces__srv__NavigationRequest_Response
    std::shared_ptr<agent_interfaces::srv::NavigationRequest_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__agent_interfaces__srv__NavigationRequest_Response
    std::shared_ptr<agent_interfaces::srv::NavigationRequest_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const NavigationRequest_Response_ & other) const
  {
    if (this->authorized != other.authorized) {
      return false;
    }
    if (this->path != other.path) {
      return false;
    }
    if (this->denial_reason != other.denial_reason) {
      return false;
    }
    if (this->ooswaittime != other.ooswaittime) {
      return false;
    }
    return true;
  }
  bool operator!=(const NavigationRequest_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct NavigationRequest_Response_

// alias to use template instance with default allocator
using NavigationRequest_Response =
  agent_interfaces::srv::NavigationRequest_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace agent_interfaces

namespace agent_interfaces
{

namespace srv
{

struct NavigationRequest
{
  using Request = agent_interfaces::srv::NavigationRequest_Request;
  using Response = agent_interfaces::srv::NavigationRequest_Response;
};

}  // namespace srv

}  // namespace agent_interfaces

#endif  // AGENT_INTERFACES__SRV__DETAIL__NAVIGATION_REQUEST__STRUCT_HPP_
